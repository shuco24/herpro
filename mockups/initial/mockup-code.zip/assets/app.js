
document.addEventListener('DOMContentLoaded', ()=>{
  // Tema
  const d=document.getElementById('setDark'), l=document.getElementById('setLight');
  if(d) d.onclick = e => { e.preventDefault(); document.documentElement.setAttribute('data-bs-theme','dark'); };
  if(l) l.onclick = e => { e.preventDefault(); document.documentElement.setAttribute('data-bs-theme','light'); };

  // Banner helper
  window.showBanner = function(msg, type="danger"){
    const area=document.getElementById('bannerArea'); if(!area) return;
    area.innerHTML = `<div class="alert alert-${type} alert-dismissible" role="alert">
      ${msg}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>`;
  };

  // Dinámica lenguas
  const list=document.getElementById('langs-list');
  const tmpl=document.getElementById('lang-template');
  const addBtn=document.querySelector('[data-action="add-lang"]');
  if(addBtn && list && tmpl){
    addBtn.addEventListener('click', ()=>{
      const node=tmpl.content.firstElementChild.cloneNode(true);
      list.appendChild(node);
      requestAnimationFrame(()=>node.classList.add('show'));
    });
    document.addEventListener('click', (e)=>{
      const btn=e.target.closest('[data-action="remove-lang"]');
      if(!btn) return;
      const row=btn.closest('.lang-row');
      row.classList.remove('show');
      setTimeout(()=>row.remove(), 200);
    });
  }

  // Estancias collapse (requiere bootstrap dentro de Tabler)
  const extra=document.getElementById('estancias-extra');
  if(extra && window.bootstrap && bootstrap.Collapse){
    const when=document.querySelector('input[name="cuando"]');
    const time=document.querySelector('input[name="tiempo"]');
    const inst=bootstrap.Collapse.getOrCreateInstance(extra, {toggle:false});
    function setStay(on){
      on ? inst.show() : inst.hide();
      if(when && time){ when.disabled=!on; time.disabled=!on; if(!on){ when.value=""; time.value=""; } }
    }
    document.querySelectorAll('input[name="pais"]').forEach(r=>{
      r.addEventListener('change', ()=> setStay(r.value==="Sí" && r.checked));
    });
    setStay(false);
  }

  // Validación en index
  const form=document.getElementById('mainForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const req=form.querySelectorAll('[required]');
      let ok=true; req.forEach(el=>{ if(!el.value) ok=false; });
      if(!ok){ showBanner("Faltan campos obligatorios."); window.scrollTo({top:0,behavior:"smooth"}); return; }
      showBanner("Formulario válido, comenzando test…","success");
    });
  }

  // Mapa (dashboard) - gracioso si falta la lib
  const mapEl=document.getElementById('map-spain');
  if(mapEl){
    if (window.jsVectorMap) {
      new jsVectorMap({selector:'#map-spain', map:'spain'});
    } else {
      mapEl.innerHTML = '<div class="text-secondary">Falta jsVectorMap. Coloca los archivos en <code>vendor/jsvectormap</code> y revisa las rutas.</div>';
    }
  }
});
